module.exports = {
    "plugins": [ ],
    "extends": [
      "eslint:recommended"
    ],
    "parser": "babel-eslint",
    "env": {
      "browser": true,
      "commonjs": true,
      "es6": true,
      "node": true,
      "jquery": true
    }
  };