<!-- START doctoc generated TOC please keep comment here to allow auto update -->
<!-- DON'T EDIT THIS SECTION, INSTEAD RE-RUN doctoc TO UPDATE -->
**Table of Contents**  *generated with [DocToc](https://github.com/thlorenz/doctoc)*

- [colorbrewer](#colorbrewer)

<!-- END doctoc generated TOC please keep comment here to allow auto update -->

colorbrewer
===========

Color specifications and designs developed by Cynthia Brewer (http://colorbrewer2.org/).

This is a shim module of colorbrewer2 by Cythina Brewer for browserify.

It is also a shim for the [files provided in d3.js lib](https://github.com/mbostock/d3/tree/master/lib/colorbrewer).
